# Datasets
Essa pasta contém todas as versões do dataset a ser utilizado!
Favor seguir a convenção de nomes de dataset (somar um no número à esquerda do ponto)!

(O dataset ```1.0v``` são simplesmente os dados fornecidos pelo DMC2020.)
